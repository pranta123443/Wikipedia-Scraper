## 🚀 Features

- **Live Scraping**: Gets the latest data from Wikipedia
- **Dropdown Selection**: Choose Country and the Quantity of the pages
## 🛠 Requirements

Make sure you have **Python 3.8+** and **pip** installed.  
Install the required Python packages:

### 📦 Install  Requirements.txy

pip install -r requirements.txt

url: http://127.0.0.1:5000/login
Username: admin
Password: admin